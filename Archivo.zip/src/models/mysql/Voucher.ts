import db from '../../db/connection';
import { DataTypes } from 'sequelize';

const Voucher = db.define('Vouchers', {
    id: {
        type: DataTypes.STRING,
        primaryKey: true,
    },
    name: {
        type: DataTypes.STRING,
    },
    category: {
        type: DataTypes.STRING
    },
    price: {
        type: DataTypes.FLOAT
    },
    image: {
        type: DataTypes.STRING
    },
    stock: {
        type: DataTypes.INTEGER
    },
    quantity: {
        type: DataTypes.INTEGER
    },
    description: {
        type: DataTypes.STRING
    }
}, {timestamps: false})

export default Voucher;